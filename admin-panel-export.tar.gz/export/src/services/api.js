// Локальные данные для автономного фронтенда

const localData = {
  dashboard: {
    success: true,
    data: {
      total_models: 1250,
      pending_models: 45,
      approved_models: 1180,
      rejected_models: 25,
      total_users: 340,
      active_users: 285,
      monthly_uploads: [120, 150, 180, 165, 200, 220, 195, 210, 185, 225, 240, 260],
      daily_downloads: [45, 67, 52, 78, 89, 65, 72],
      revenue: 125000
    }
  },

  models: [
    { id: 1, name: "Современный стул", status: "approved", author: "Дмитрий К.", category: "Мебель", downloads: 150 },
    { id: 2, name: "Деревянный стол", status: "pending", author: "Анна С.", category: "Мебель", downloads: 89 },
    { id: 3, name: "Спортивный автомобиль", status: "approved", author: "Максим П.", category: "Транспорт", downloads: 275 },
    { id: 4, name: "Настольная лампа", status: "rejected", author: "Елена В.", category: "Освещение", downloads: 0 },
    { id: 5, name: "Архитектурное здание", status: "pending", author: "Сергей Л.", category: "Архитектура", downloads: 45 }
  ],

  users: [
    { id: 1, username: "dmitry_k", email: "dmitry@example.com", role: "user", is_active: true, models_count: 12 },
    { id: 2, username: "anna_s", email: "anna@example.com", role: "moderator", is_active: true, models_count: 8 },
    { id: 3, username: "maxim_p", email: "maxim@example.com", role: "user", is_active: true, models_count: 25 },
    { id: 4, username: "elena_v", email: "elena@example.com", role: "user", is_active: false, models_count: 3 },
    { id: 5, username: "sergey_l", email: "sergey@example.com", role: "user", is_active: true, models_count: 7 }
  ],

  categories: [
    { id: 1, name: "Архитектура", name_en: "Architecture", position: 1, models_count: 25 },
    { id: 2, name: "Мебель", name_en: "Furniture", position: 2, models_count: 150 },
    { id: 3, name: "Транспорт", name_en: "Transport", position: 3, models_count: 75 },
    { id: 4, name: "Декор", name_en: "Decor", position: 4, models_count: 90 },
    { id: 5, name: "Освещение", name_en: "Lighting", position: 5, models_count: 45 }
  ],

  sections: [
    { id: 1, name: "Интерьер", models_count: 320 },
    { id: 2, name: "Экстерьер", models_count: 180 },
    { id: 3, name: "Техника", models_count: 95 },
    { id: 4, name: "Природа", models_count: 65 }
  ]
};

// Функция для симуляции асинхронных запросов
const simulateRequest = (data, delay = 500) => {
  return new Promise((resolve) => {
    setTimeout(() => resolve({ data }), delay);
  });
};

// API методы для аутентификации
export const auth = {
  async login(credentials) {
    // Локальная аутентификация для демо
    if (credentials.email === 'admin@example.com' && credentials.password === 'admin123') {
      const token = 'demo_token_' + Date.now();
      localStorage.setItem('auth_token', token);
      return { success: true, token, user: { id: 1, email: credentials.email, role: 'admin' } };
    }
    throw new Error('Неверные учетные данные');
  },

  async logout() {
    localStorage.removeItem('auth_token');
    return { success: true };
  },

  async user() {
    const token = localStorage.getItem('auth_token');
    if (token) {
      return { id: 1, email: 'admin@example.com', role: 'admin' };
    }
    throw new Error('Не авторизован');
  }
};

// API методы для моделей 3D
export const models = {
  async getAll(params = {}) {
    return simulateRequest(localData.models);
  },

  async getById(id) {
    const model = localData.models.find(model => model.id === parseInt(id));
    return simulateRequest(model);
  },

  async create(modelData) {
    const newModel = {
      id: localData.models.length + 1,
      ...modelData,
      status: 'pending',
      downloads: 0
    };
    localData.models.push(newModel);
    return simulateRequest(newModel);
  },

  async update(id, modelData) {
    const index = localData.models.findIndex(model => model.id === parseInt(id));
    if (index !== -1) {
      localData.models[index] = { ...localData.models[index], ...modelData };
      return simulateRequest(localData.models[index]);
    }
    throw new Error('Модель не найдена');
  },

  async delete(id) {
    const index = localData.models.findIndex(model => model.id === parseInt(id));
    if (index !== -1) {
      localData.models.splice(index, 1);
      return simulateRequest({ success: true });
    }
    throw new Error('Модель не найдена');
  },

  async moderate(id, action, comment = '') {
    const index = localData.models.findIndex(model => model.id === parseInt(id));
    if (index !== -1) {
      localData.models[index].status = action;
      localData.models[index].moderationComment = comment;
      return simulateRequest(localData.models[index]);
    }
    throw new Error('Модель не найдена');
  },

  async getHistory(id) {
    return simulateRequest([
      { date: '2024-01-15', action: 'created', user: 'Автор' },
      { date: '2024-01-16', action: 'submitted', user: 'Автор' },
      { date: '2024-01-17', action: 'reviewed', user: 'Модератор' }
    ]);
  }
};

// API методы для дашборда
export const dashboard = {
  async getStats() {
    return simulateRequest(localData.dashboard);
  }
};

// API методы для пользователей
export const users = {
  async getAll(params = {}) {
    return simulateRequest(localData.users);
  }
};

// API методы для категорий
export const categories = {
  async getAll() {
    return simulateRequest(localData.categories);
  }
};

// API методы для разделов
export const sections = {
  async getAll() {
    return simulateRequest(localData.sections);
  }
};